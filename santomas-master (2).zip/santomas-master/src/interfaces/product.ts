export default interface IProduct {
    id: number | string
    name: string
    key_QR: string
    target: string
    pac: string
    box: string
    note: string
}